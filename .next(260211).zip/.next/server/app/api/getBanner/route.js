"use strict";(()=>{var e={};e.id=560,e.ids=[560],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},5520:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>x,patchFetch:()=>f,requestAsyncStorage:()=>h,routeModule:()=>c,serverHooks:()=>m,staticGenerationAsyncStorage:()=>g});var n={};r.r(n),r.d(n,{GET:()=>u,dynamic:()=>p});var a=r(3278),s=r(5002),i=r(4877),o=r(1309),l=r(2784);let p="force-dynamic",d=process.env.FENCING_API_BASE_URL||"https://yyfencing.oss-cn-beijing.aliyuncs.com/fencingscore";async function u(e){let t=new URL(e.url).searchParams.get("sportCode");if(!t)return o.NextResponse.json({error:"Missing required parameter: sportCode"},{status:400});let r=`${d}/${t}`,n=`${r}/banner.jpg`;try{let e=await fetch(n,{method:"GET",next:{revalidate:l.L}});if(404===e.status){let e=`
        <svg width="800" height="400" xmlns="http://www.w3.org/2000/svg">
          <rect width="100%" height="100%" fill="#3B82F6"/>
          <text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="white" font-size="24" font-family="Arial, sans-serif">
            ${t}
          </text>
          <text x="50%" y="60%" text-anchor="middle" dy=".3em" fill="white" font-size="16" font-family="Arial, sans-serif">
            运动项目横幅
          </text>
        </svg>
      `;return new o.NextResponse(e,{status:200,headers:{"Content-Type":"image/svg+xml","Cache-Control":"public, max-age=600"}})}if(!e.ok)throw console.error(`Failed to fetch banner ${n}: ${e.status} ${e.statusText}`),Error(`Failed to fetch image: ${e.status} ${e.statusText}`);let r=new Headers,a=e.headers.get("content-type");return a&&r.set("Content-Type",a),r.set("Cache-Control",`public, max-age=${l.L}, stale-while-revalidate=5`),new o.NextResponse(e.body,{status:200,statusText:"OK",headers:r})}catch(t){console.error("Error fetching banner image:",t);let e=`
      <svg width="800" height="400" xmlns="http://www.w3.org/2000/svg">
        <rect width="100%" height="100%" fill="#6B7280"/>
        <text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="white" font-size="20" font-family="Arial, sans-serif">
          无法加载横幅图片
        </text>
      </svg>
    `;return new o.NextResponse(e,{status:200,headers:{"Content-Type":"image/svg+xml","Cache-Control":"public, max-age=300"}})}}let c=new a.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/getBanner/route",pathname:"/api/getBanner",filename:"route",bundlePath:"app/api/getBanner/route"},resolvedPagePath:"E:\\work\\fencing-championship-v2\\app\\api\\getBanner\\route.ts",nextConfigOutput:"",userland:n}),{requestAsyncStorage:h,staticGenerationAsyncStorage:g,serverHooks:m}=c,x="/api/getBanner/route";function f(){return(0,i.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:g})}},2784:(e,t,r)=>{r.d(t,{L:()=>n});let n=15}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[787,833],()=>r(5520));module.exports=n})();